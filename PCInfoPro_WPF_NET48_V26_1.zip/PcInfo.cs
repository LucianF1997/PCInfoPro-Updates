using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Management;
using Microsoft.Win32;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;

namespace PCInfoPro
{
    public static class PcInfo
    {
        public static string GetQuickInfo()
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                ManagementObject cs = First("Win32_ComputerSystem"), csp = First("Win32_ComputerSystemProduct"), bb = First("Win32_BaseBoard"), cpu = First("Win32_Processor"), bat = First("Win32_Battery");
                long totalRam = 0; int speed = 0; int memType = 0;
                foreach (ManagementObject m in All("Win32_PhysicalMemory")) { totalRam += ToLong(GetVal(m,"Capacity")); if(speed==0) speed=ToInt(GetVal(m,"Speed")); if(memType==0) memType=ToInt(GetVal(m,"SMBIOSMemoryType")); }
                sb.AppendLine(SystemType(ToInt(GetVal(cs,"PCSystemType"))) + ": " + S(GetVal(cs,"Manufacturer")) + " " + ResolveModel(cs,csp,bb));
                sb.AppendLine("Procesor: " + S(GetVal(cpu,"Name")));
                foreach (ManagementObject g in All("Win32_VideoController"))
                {
                    string name=S(GetVal(g,"Name")); long ram=ToLong(GetVal(g,"AdapterRAM")); long gb=ram>0?(long)Math.Round(ram/1024.0/1024.0/1024.0,0):0;
                    sb.AppendLine((Regex.IsMatch(name,"Intel",RegexOptions.IgnoreCase)?"Placa video integrata: ":"Placa video dedicata: ") + name + (gb>0?" ("+gb+" GB)":""));
                }
                sb.AppendLine("RAM: " + Math.Round(totalRam/1024.0/1024/1024,0) + " GB " + RamType(memType) + " " + speed + " MHz");
                int i=1; foreach(ManagementObject d in All("Win32_DiskDrive")) { sb.AppendLine("Disk "+(i++)+": "+DiskLine(d)); }
                if(bat!=null) sb.AppendLine("Procent bateria: " + S(GetVal(bat,"EstimatedChargeRemaining")) + "%");
                string health=BatteryHealth(); if(health.Length>0) sb.AppendLine("Stare sanatate baterie : " + health);
                if(bat!=null) sb.AppendLine("Numarul de cicluri: " + BatteryCycles());
            } catch(Exception ex){ sb.AppendLine("EROARE: "+ex.Message); }
            return sb.ToString().TrimEnd();
        }
        public static string GetInfo1C()
        {
            try
            {
                ManagementObject cs=First("Win32_ComputerSystem"), csp=First("Win32_ComputerSystemProduct"), bb=First("Win32_BaseBoard"), cpu=First("Win32_Processor"), disk=FirstInternalDisk();
                long totalRam=0; foreach(ManagementObject m in All("Win32_PhysicalMemory")) totalRam+=ToLong(GetVal(m,"Capacity"));
                string gpu=PreferredGpuName();
                string storage=AllStorageShort();
                return SystemType(ToInt(GetVal(cs,"PCSystemType"))) + ": " + S(GetVal(cs,"Manufacturer")) + " " + ResolveModel(cs,csp,bb) + Environment.NewLine +
                       "Parametri: " + CleanCpu(S(GetVal(cpu,"Name"))) + ", " + Math.Round(totalRam/1024.0/1024/1024,0) + " GB RAM / " + storage + ", " + gpu;
            } catch(Exception ex){ return "EROARE: "+ex.Message; }
        }
        public static string GetPreturi()
        {
            try
            {
                ManagementObject cpu=First("Win32_Processor"), disk=FirstInternalDisk(), gpu=PreferredGpu();
                long ram=0; foreach(ManagementObject m in All("Win32_PhysicalMemory")) ram+=ToLong(GetVal(m,"Capacity"));
                string storage=AllStorageDetailed();
                long vram=ToLong(GetVal(gpu,"AdapterRAM")); long gb=vram>0?(long)Math.Round(vram/1024.0/1024.0/1024.0,0):0; string gpuLine=S(GetVal(gpu,"Name"))+(gb>0?" ("+gb+" GB)":"");
                return "Display: " + DisplayInfo() + Environment.NewLine + CleanCpu(S(GetVal(cpu,"Name"))) + Environment.NewLine + "Memorie: " + Math.Round(ram/1024.0/1024/1024,0) + " GB RAM / " + storage + Environment.NewLine + gpuLine;
            } catch(Exception ex){ return "EROARE: "+ex.Message; }
        }
        public static string GetBiosInfo()
        {
            try{ ManagementObject cs=First("Win32_ComputerSystem"), csp=First("Win32_ComputerSystemProduct"), bb=First("Win32_BaseBoard"); return "=== Verificare parola BIOS ===\nProducator: "+S(GetVal(cs,"Manufacturer"))+"\nModel Windows: "+S(GetVal(cs,"Model"))+"\nProduct Name: "+ResolveModel(cs,csp,bb)+"\nBaseBoard Product: "+S(GetVal(bb,"Product"))+"\n\nNu s-a detectat automat o parola BIOS. Pentru verificare manuala, reporniti in BIOS/UEFI."; }catch(Exception ex){return "EROARE: "+ex.Message;}
        }
        public static void RebootToBios(){ try{ var psi=new ProcessStartInfo("shutdown.exe","/r /fw /t 5"); psi.Verb="runas"; psi.UseShellExecute=true; Process.Start(psi);} catch(Exception ex){ MessageBox.Show("Eroare la repornire: "+ex.Message); } }
        private static ManagementObject First(string cls){ foreach(ManagementObject o in All(cls)) return o; return null; }
        private static List<ManagementObject> All(string cls){ var l=new List<ManagementObject>(); try{ using(var s=new ManagementObjectSearcher("root\\cimv2","SELECT * FROM "+cls)) foreach(ManagementObject o in s.Get()) l.Add(o);}catch{} return l; }
        private static object GetVal(ManagementObject o,string p){ try{return o==null?null:o[p];}catch{return null;} }
        private static string S(object o){return o==null?"":Convert.ToString(o,CultureInfo.InvariantCulture).Trim();}
        private static int ToInt(object o){int v; return int.TryParse(S(o),out v)?v:0;} private static long ToLong(object o){long v; return long.TryParse(S(o),out v)?v:0;}
        private static string SystemType(int t){return t==2?"Laptop":(t==1?"Desktop":"Calculator");}
        private static string RamType(int t){return t==34?"DDR5":(t==26?"DDR4":(t==24?"DDR3":"RAM"));}
        private static string Size(long s){ if(s<=0)return"N/A"; return s>=1000000000000L?(s/1000000000000.0).ToString("0.0")+" TB":Math.Round(s/1000000000.0,0)+" GB"; }
        private static string DiskLine(ManagementObject d){ string model=S(GetVal(d,"Model")); return model+" - "+Size(ToLong(GetVal(d,"Size")))+" "+DiskType(model,S(GetVal(d,"InterfaceType"))); }
        private static string DiskType(string model,string interf){ int mt=StorageMediaType(model); if(mt==4)return Regex.IsMatch(interf,"NVMe",RegexOptions.IgnoreCase)||Regex.IsMatch(model,"nvme|pcie|mzvl|pm9|snv|wd.*sn",RegexOptions.IgnoreCase)?"NVMe SSD":"SSD"; if(mt==3)return"HDD"; if(Regex.IsMatch(interf,"NVMe",RegexOptions.IgnoreCase)||Regex.IsMatch(model,"nvme|mzvl|pm9|snv|pcie|wd.*sn",RegexOptions.IgnoreCase))return"NVMe SSD"; if(Regex.IsMatch(model,"ssd|solid|evo|qvo|kingston|crucial|sandisk|adata|patriot|lexar|sk hynix|hfs|samsung mz|intel ssd",RegexOptions.IgnoreCase))return"SATA SSD"; if(Regex.IsMatch(interf,"USB",RegexOptions.IgnoreCase))return"USB Drive"; return"HDD"; }
        private static int StorageMediaType(string model){ try{ foreach(ManagementObject o in Query("root\\Microsoft\\Windows\\Storage","MSFT_PhysicalDisk")){ string f=S(GetVal(o,"FriendlyName")); if(model.Length>0 && f.Length>0 && (model.IndexOf(f,StringComparison.OrdinalIgnoreCase)>=0 || f.IndexOf(model,StringComparison.OrdinalIgnoreCase)>=0)){ int mt=ToInt(GetVal(o,"MediaType")); if(mt>0)return mt; } } }catch{} return 0; }
        private static string ShortDisk(string t){return t.Contains("SSD")?"SSD":(t.Contains("USB")?"USB":"HDD");}
        private static string AllStorageShort(){ List<string> parts=new List<string>(); foreach(ManagementObject d in All("Win32_DiskDrive")){ if(Regex.IsMatch(S(GetVal(d,"InterfaceType")),"USB",RegexOptions.IgnoreCase))continue; string type=ShortDisk(DiskType(S(GetVal(d,"Model")),S(GetVal(d,"InterfaceType")))); parts.Add(Size(ToLong(GetVal(d,"Size")))+" "+type); } return parts.Count>0?string.Join(" + ",parts.ToArray()):"fara disc intern"; }
        private static string AllStorageDetailed(){ List<string> parts=new List<string>(); foreach(ManagementObject d in All("Win32_DiskDrive")){ if(Regex.IsMatch(S(GetVal(d,"InterfaceType")),"USB",RegexOptions.IgnoreCase))continue; parts.Add(Size(ToLong(GetVal(d,"Size")))+" "+DiskType(S(GetVal(d,"Model")),S(GetVal(d,"InterfaceType")))); } return parts.Count>0?string.Join(" + ",parts.ToArray()):"fara disc intern"; }
        private static string CleanCpu(string s){return Regex.Replace(Regex.Replace(s,"CPU @.*$","",RegexOptions.IgnoreCase),"\\s+$","");}
        private static ManagementObject FirstInternalDisk(){ foreach(ManagementObject d in All("Win32_DiskDrive")) if(!Regex.IsMatch(S(GetVal(d,"InterfaceType")),"USB",RegexOptions.IgnoreCase)) return d; return null; }
        private static ManagementObject PreferredGpu(){ ManagementObject first=null; foreach(ManagementObject g in All("Win32_VideoController")){ if(first==null)first=g; if(!Regex.IsMatch(S(GetVal(g,"Name")),"Intel",RegexOptions.IgnoreCase))return g;} return first; }
        private static string PreferredGpuName(){ return S(GetVal(PreferredGpu(),"Name")); }
        private static string ResolveModel(ManagementObject cs,ManagementObject csp,ManagementObject bb){ string model=S(GetVal(cs,"Model")); string cspn=S(GetVal(csp,"Name")); string cspv=S(GetVal(csp,"Version")); string bbp=S(GetVal(bb,"Product")); if(Good(cspv) && cspv.Length>cspn.Length) return cspv; if(Good(cspn) && !Regex.IsMatch(cspn,"^[A-Z0-9]{3,6}$")) return cspn; if(Good(model) && !Regex.IsMatch(model,"^[A-Z0-9]{3,6}$")) return model; return Good(cspv)?cspv:(Good(cspn)?cspn:(Good(model)?model:bbp)); }
        private static bool Good(string s){return s.Length>0&&!Regex.IsMatch(s,"To be filled|System Product|Default|string|OEM|None|Not Available",RegexOptions.IgnoreCase);}
        private static string DisplayInfo()
        {
            try
            {
                int x=0,y=0;
                foreach(ManagementObject v in All("Win32_VideoController"))
                {
                    x=ToInt(GetVal(v,"CurrentHorizontalResolution"));
                    y=ToInt(GetVal(v,"CurrentVerticalResolution"));
                    if(x>0&&y>0)break;
                }
                string res=x>0&&y>0?x+"x"+y:"N/A";
                string inch=EdidInches();
                return inch.Length>0 ? inch + "\", " + res : res;
            }
            catch{return"N/A";}
        }
        private static string EdidInches()
        {
            try
            {
                RegistryKey root=Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Enum\DISPLAY");
                if(root==null)return"";
                foreach(string m in root.GetSubKeyNames()) using(RegistryKey km=root.OpenSubKey(m))
                {
                    if(km==null)continue;
                    foreach(string id in km.GetSubKeyNames()) using(RegistryKey kp=km.OpenSubKey(id+@"\Device Parameters"))
                    {
                        if(kp==null)continue;
                        byte[] edid=kp.GetValue("EDID") as byte[];
                        double inches=InchesFromEdid(edid);
                        if(inches>5 && inches<100) return NormalizeInches(inches).ToString("0.0", CultureInfo.InvariantCulture);
                    }
                }
            }
            catch{}
            return"";
        }
        private static double InchesFromEdid(byte[] edid)
        {
            if(edid==null || edid.Length<23) return 0;
            // Prefer detailed timing descriptor physical size in millimeters.
            for(int off=54; off+17<edid.Length && off<=108; off+=18)
            {
                int hActiveLo=edid[off+2];
                int vActiveLo=edid[off+5];
                int hMm=edid[off+12] + ((edid[off+14] & 0xF0) << 4);
                int vMm=edid[off+13] + ((edid[off+14] & 0x0F) << 8);
                if(hActiveLo>0 && vActiveLo>0 && hMm>100 && vMm>50)
                    return Math.Sqrt(hMm*hMm + vMm*vMm) / 25.4;
            }
            // Fallback: basic EDID screen size in centimeters.
            int hCm=edid[21], vCm=edid[22];
            if(hCm>0 && vCm>0) return Math.Sqrt(hCm*hCm + vCm*vCm) / 2.54;
            return 0;
        }
        private static double NormalizeInches(double value)
        {
            // EDID often reports coarse cm values, e.g. 15.3 for a real 15.6 panel.
            double[] common={10.1,11.6,12.1,12.5,13.3,14.0,15.0,15.6,16.0,17.3,18.4,19.0,21.5,23.8,24.0,27.0,32.0};
            double best=value, diff=999;
            foreach(double c in common){ double d=Math.Abs(c-value); if(d<diff){diff=d; best=c;} }
            return diff<=0.55 ? best : value;
        }
        private static List<ManagementObject> Query(string ns,string cls){var l=new List<ManagementObject>(); try{using(var s=new ManagementObjectSearcher(ns,"SELECT * FROM "+cls))foreach(ManagementObject o in s.Get())l.Add(o);}catch{} return l;}
        private static string BatteryHealth(){ try{var fc=Query("root\\wmi","BatteryFullChargedCapacity"); var sd=Query("root\\wmi","BatteryStaticData"); if(fc.Count>0&&sd.Count>0){double f=ToLong(GetVal(fc[0],"FullChargedCapacity")); double d=ToLong(GetVal(sd[0],"DesignedCapacity")); if(d>0)return Math.Round(f/d*100,1)+"%";}}catch{} return"";}
        private static string BatteryCycles(){ try{var bc=Query("root\\wmi","BatteryCycleCount"); if(bc.Count>0){object c=GetVal(bc[0],"CycleCount")??GetVal(bc[0],"Count"); if(c!=null)return S(c);}}catch{} return"N/A";}
    }
}
