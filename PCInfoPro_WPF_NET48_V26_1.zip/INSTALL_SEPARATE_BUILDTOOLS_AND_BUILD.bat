@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title PCInfoPro - Build Tools checker and build
if not exist "PCInfoPro.csproj" (echo PCInfoPro.csproj not found.& pause & exit /b 1)
net session >nul 2>&1
if not %errorlevel%==0 (echo Run as Administrator.& pause & exit /b 1)
set "INSTALLPATH=C:\VSBuildToolsPCInfo"
set "MSBUILD=%INSTALLPATH%\MSBuild\Current\Bin\MSBuild.exe"
set "ROSLYN=%INSTALLPATH%\MSBuild\Current\Bin\Roslyn\Microsoft.CSharp.Core.targets"
if exist "%MSBUILD%" if exist "%ROSLYN%" (
  echo Build Tools already installed. Skipping installation.
  goto build_project
)
set "TEMP_DIR=%TEMP%\PCInfoProBuildTools"
set "VS_BOOTSTRAPPER=%TEMP_DIR%\vs_buildtools.exe"
set "VS_URL=https://aka.ms/vs/17/release/vs_buildtools.exe"
set "LOG=%~dp0install_buildtools_log.txt"
if not exist "%TEMP_DIR%" mkdir "%TEMP_DIR%"
echo Downloading Build Tools...
powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%VS_URL%' -OutFile '%VS_BOOTSTRAPPER%'" > "%LOG%" 2>&1
if errorlevel 1 (echo Download failed. See log.& type "%LOG%"& pause & exit /b 1)
echo Installing Build Tools to %INSTALLPATH% ...
start /wait "VS Build Tools Setup" "%VS_BOOTSTRAPPER%" --installPath "%INSTALLPATH%" --passive --wait --norestart ^
  --add Microsoft.VisualStudio.Workload.ManagedDesktopBuildTools ^
  --add Microsoft.VisualStudio.Component.Roslyn.Compiler ^
  --add Microsoft.VisualStudio.Component.NuGet.BuildTools ^
  --add Microsoft.Net.Component.4.8.SDK ^
  --add Microsoft.Net.Component.4.8.TargetingPack ^
  --includeRecommended >> "%LOG%" 2>&1
if not exist "%MSBUILD%" (echo MSBuild not found. Restart Windows and run again.& pause & exit /b 1)
if not exist "%ROSLYN%" (echo Roslyn missing. Restart Windows and run again.& pause & exit /b 1)
:build_project
"%MSBUILD%" PCInfoPro.csproj /p:Configuration=Release /p:Platform="AnyCPU"
if errorlevel 1 (echo Build failed.& pause & exit /b 1)
echo SUCCESS: bin\Release\PCInfoPro.exe
pause
