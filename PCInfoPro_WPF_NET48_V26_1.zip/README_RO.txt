PCInfoPro V3 FULL

Versiune completa actualizata si buna:
- Programul porneste pe tot ecranul (WindowState=Maximized).
- Informatii rapide, Info 1C si Preturi au fost refacute si functioneaza din nou.
- Test tastatura: text sus, tastatura la mijloc, Space se marcheaza, ESC se apasa de doua ori.
- Test USB: arata dispozitive deja conectate si cele conectate dupa pornirea testului.
- Test Camera: fereastra cu butoane Deschide Camera si Deschide folder Camera.
- Rapoartele, audio, camera, usb etc. se salveaza langa program in folderul Teste.

Build recomandat:
1. Ruleaza ca Administrator: INSTALL_SEPARATE_BUILDTOOLS_AND_BUILD.bat
2. Dupa aceea pentru build rapid: BUILD_ONLY_SEPARATE_BUILDTOOLS.bat


FIX: Adaugata clasa CacheData care lipsea si cauza eroarea CS0246.


V4:
- Installerul verifica intai daca Build Tools exista deja; daca exista, NU mai instaleaza.
- Info 1C si Preturi au fost refacute cu model/denumire si GB placa video.
- Tastatura: Backspace reparat, toate tastele sunt blocate in fereastra de test, NumPad adaugat, apasarile repetate lumineaza mai tare.
- USB: lista este mai clara si explica limitarea portului fizic.
- Adaugat buton Iesire.


V5:
- Tastatura salveaza in raport tastele verificate si numarul de apasari.
- Tastele stanga/dreapta sunt separate: LShift/RShift/LCtrl/RCtrl/LAlt/RAlt.
- Backspace reparat, NumPad adaugat, apasari repetate lumineaza mai tare.
- USB este mai minimal si clar; nu mai spune ca portul liber e conectat.
- Model laptop: prefera denumirea completa din BIOS/SystemProduct Version, ex. IdeaPad L340-15IRH Gaming.
- Camera: adaugat test virtual doar pentru raport daca nu exista camera fizica; nu poate verifica hardware in lipsa camerei.


V6:
- Adaugat buton Fn in test tastatura. Fn in mod normal nu este trimis catre Windows; se poate marca manual cu click pe buton.
- PrtSc mapat si pentru PrintScreen/SysRq; daca laptopul nu trimite eveniment, se poate marca manual cu click.
- ] si ; mapate si pe codurile Oem6/Oem1; / pe Oem2, [ pe Oem4, apostrof pe Oem7.
- Toate tastele din harta pot fi marcate si cu click manual.
- NumPad corectat: + si Enter nu mai apar de doua ori una langa alta.
- Test camera are buton Instaleaza Camera, care deschide Microsoft Store la aplicatia Camera.

Nota: daca laptopul nu are camera fizica, programul nu poate crea/testa hardware real. Poza virtuala este doar pentru raport, nu verifica camera.


V7:
- Tastatura: Fn poate fi marcat manual cu click; Windows de obicei nu trimite Fn catre aplicatie.
- PrtSc si alte taste speciale pot fi marcate manual cu click daca laptopul nu trimite eveniment.
- Adaugat cluster stationar: Insert, Home, PageUp, Delete, End, PageDown si sageti cu simboluri ↑ ↓ ← →.
- NumPad corectat vizual: + si Enter sunt afisate o singura data pe coloana, fara dubluri una langa alta.
- Camera: adaugat buton Importa poze/video; copiaza fisiere din Pictures\Camera Roll in folderul raportului Camera.


V8:
- Microfon: adaugat erori MCI clare, buton Sound Recorder si Importa inregistrari audio.
- Tastatura: Enter principal si NumPad Enter raman separate; nu se mai aprind impreuna. Daca Windows nu le deosebeste, NumPad Enter poate fi marcat manual cu click.
- Apasarile repetate nu mai schimba nuanta permanent; numarul de apasari se vede in raport.


V9:
- Microfon: salvare MCI reparata prin fisier temporar simplu, apoi copiere in raport. Daca MCI tot nu merge, ramane metoda Sound Recorder + Importa.
- Preturi/Display: incearca sa citeasca diagonala ecranului din EDID si afiseaza inch + rezolutie.
- HDD/SSD: detectare imbunatatita prin MSFT_PhysicalDisk si afisare toate discurile interne: SSD + HDD, nu doar primul disc.


V10:
- Preturi/Display reparat: citeste diagonala din EDID mai corect, foloseste descriptorul in mm cand exista si normalizeaza valori comune ca 15.6 inch.
- Formatul foloseste punct: 15.6 inch, nu 15. sau 15,6.


V11:
- Preturi Display afiseaza format cu ghilimele: 15.6", nu 15.3 inch. Pragul de normalizare EDID a fost marit pentru panouri 15.6 raportate ca 15.3.
- Tastatura: Enter principal si Enter NumPad raman separate; Enter NumPad este afisat clar ca Enter N.
- Iluminatie tastatura: la inceput gri, la apasare verde, daca tasta este tinuta apasata si apar repetari devine rosu cat timp este tinuta; la eliberare revine verde.


V12:
- Tastatura: Fn/PrtSc/PgDn/Enter N pot fi marcate sigur cu click pe buton daca Windows nu trimite semnal. Click-ul manual a fost reparat prin PreviewMouseLeftButtonDown.
- Logica culori: prima apasare verde; apasarea a doua/urmatoarele rosie scurt, apoi revine verde. In raport ramane numarul de apasari.
- Enter N ramane separat; daca Windows nu il trimite diferit, marcheaza manual cu click pe Enter N.


V13:
- Header schimbat: „Informație despre Calculator” și „Creat de Filiuc Lucian” centrat. „PC Info Pro” și „WPF .NET 4.8” au fost eliminate din interfață.
- Meniul are scris mai mare și textul butoanelor centrat.
- În test tastatură am adăugat butoane manuale separate sus pentru Fn, PrtSc, PgDn și Enter N. Acestea vor marca sigur tastele chiar dacă Windows/laptopul nu trimite semnal fizic.


V14 OK: butoanele manuale au fost eliminate; folosim hook de nivel jos pentru Enter NumPad, PrtSc si PgDn. Fn este explicat ca netestabil software.


V15 OK:
- Fn nu mai este gri/deconectat. Este portocaliu, ca tasta hardware/BIOS.
- Fn se noteaza in raport ca Fn-BIOS, netestabil software, deoarece Windows nu primeste eveniment de la Fn.


V16 OK:
- Fn ramane sur/gri vizual, dar este apasabil cu mouse-ul in program.
- La click pe Fn se marcheaza verde/rosu ca restul tastelor si se adauga in raport ca Fn.


V17 OK:
- La test tastatura s-a sters textul lung de sus; ramane doar „ESC de 2 ori = ieșire”.
- Fn ramane gri, dar click-ul pe Fn a fost reparat cu AddHandler pe PreviewMouseLeftButtonDown/MouseLeftButtonDown/MouseDown, inclusiv pe textul din tasta.


V18 OK:
- Fn: am adaugat incercare de detectare prin evenimente necunoscute/OEM din hook.
- Fn ramane gri si este apasabil cu mouse-ul; click-ul foloseste evenimente normale fara AddHandler ca sa nu fie blocat de hook.
- Instructia de sus ramane doar: ESC de 2 ori = ieșire.


V19 OK:
- Butonul Fn a fost eliminat complet din test tastatura.
- Am scos si logica de detectare/click pentru Fn ca sa nu mai incurce testul.
- Sus ramane doar mesajul: ESC de 2 ori = ieșire.


V20 SECURE:
- La pornire apare doar câmp pentru cod.
- Admin: Sonyxperia, nelimitat.
- Utilizator: Primavara, 180 zile, maxim 2 activări.
- Fără cod: trial 30 zile.
- Licența se leagă de calculator și se salvează criptat lângă program, în ProgramData și în Registry.
- După expirare programul se blochează; șterge doar folderul Teste creat de program, nu EXE-ul.


V20 SECURE FIXED:
- Reparat CS1628 in SecurityManager: out parameters nu mai sunt folosite direct in delegate/lambda; folosim variabile locale si le copiem dupa inchiderea ferestrei.
- Warningurile CS0649 de la KBDLLHOOKSTRUCT sunt normale pentru structura umpluta de Windows hook.


V21 LOGIN BUTTON:
- Adăugat buton mic „Logare” în partea dreaptă sus.
- Butonul deschide fereastră pentru introducerea codului/parolei fără login.
- Se poate introduce Admin sau Utilizator în orice moment, fără restart.


V22 LOGIN STATUS:
- După logare, butonul din dreapta sus nu mai arată „Logare”, ci „Administrator”, „Utilizator” sau „Trial”, după licența activă.
- Textul se actualizează și la pornire, și imediat după introducerea parolei.


V25 STABLE creat din fisierele trimise:
- MainWindow.xaml.cs din versiunea cu login/status si teste complete.
- SecurityManager.cs cu Logare / Administrator / Utilizator / Trial.
- PcInfo.cs bun cu Info 1C, Preturi, Display EDID si detectare SSD/HDD.
- MainWindow.xaml reconstruit stabil cu LoginButton si toate butoanele necesare.
- PCInfoPro.csproj include SecurityManager.cs si System.Security.
- Installerul verifica Build Tools inainte de instalare.


V26 STABLE UPDATE:
- Adaugat buton Actualizare in dreapta sus langa Logare.
- Fereastra Actualizare verifica online fisierul update.json din GitHub.
- Daca versiunea online este mai noua, apare buton Instaleaza.
- Instaleaza descarca ZIP-ul in folderul Updates de langa program.
- Verifica SHA256 daca este completat in update.json.
- Nu instaleaza automat peste EXE-ul pornit; descarca si deschide folderul pentru instalare manuala sigura.

Fisier exemplu pentru GitHub: update.sample.json


V26.1:
- Versiune pentru testarea mecanismului de actualizare online.
- CurrentVersion actualizat la 26.1.
