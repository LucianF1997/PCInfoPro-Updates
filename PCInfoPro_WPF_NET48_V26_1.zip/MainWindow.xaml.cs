using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Management;
using System.Media;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using System.Windows.Media.Imaging;

namespace PCInfoPro
{
    public partial class MainWindow : Window
    {
        [DllImport("winmm.dll", CharSet = CharSet.Auto)]
        private static extern int mciSendString(string command, StringBuilder ret, int len, IntPtr hwnd);
        [DllImport("winmm.dll", CharSet = CharSet.Auto)]
        private static extern bool mciGetErrorString(int errorCode, StringBuilder errorText, int errorTextSize);

        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll", SetLastError = true)] private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
        [DllImport("user32.dll", SetLastError = true)] private static extern bool UnhookWindowsHookEx(IntPtr hhk);
        [DllImport("user32.dll")] private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)] private static extern IntPtr GetModuleHandle(string lpModuleName);
        private const int WH_KEYBOARD_LL = 13, WM_KEYDOWN = 0x0100, WM_SYSKEYDOWN = 0x0104, LLKHF_EXTENDED = 0x01;
        private struct KBDLLHOOKSTRUCT { public int vkCode; public int scanCode; public int flags; public int time; public IntPtr dwExtraInfo; }
        private IntPtr keyboardHook = IntPtr.Zero;
        private LowLevelKeyboardProc keyboardHookProc;
        private Dictionary<string, List<Border>> keyboardBoxes;
        private Dictionary<string, int> keyboardPresses;
        private SortedSet<string> keyboardCheckedKeys;
        private Window keyboardTestWindow;
        private int keyboardEscCount;

        private CacheData cache = new CacheData();
        private bool cacheReady, cacheLoading;
        private readonly Dictionary<string, string> testResults = new Dictionary<string, string>();
        private bool hasBattery, hasCamera, hasMicrophone;
        private string currentReportDir, currentReportPath, currentComputerNameSafe = "PCInfoPro";

        public MainWindow()
        {
            InitializeComponent();
            Loaded += async delegate
            {
                if (!SecurityManager.EnsureAccess(this)) { Close(); return; }
                LoginButton.Content = SecurityManager.CurrentModeLabel();
                DetectCapabilities();
                await StartLoadAsync(false);
            };
        }

        private async Task StartLoadAsync(bool force)
        {
            if (cacheLoading) return;
            if (cacheReady && !force) return;
            cacheReady = false; cacheLoading = true; currentReportDir = null;
            BiosRebootButton.Visibility = Visibility.Collapsed;
            TestPanel.Visibility = Visibility.Collapsed;
            SectionTitle.Text = "Cache";
            StatusText.Text = "Se proceseaza...";
            LoadingBar.Visibility = Visibility.Visible;
            OutputText.Text = "Se incarca informatia in cache...";
            try
            {
                cache = await Task.Run(delegate
                {
                    return new CacheData
                    {
                        Quick = PcInfo.GetQuickInfo(),
                        Info1C = PcInfo.GetInfo1C(),
                        Preturi = PcInfo.GetPreturi(),
                        Bios = PcInfo.GetBiosInfo()
                    };
                });
                cacheReady = true;
                EnsureReportFolder();
                SaveReportFile();
                SectionTitle.Text = "Cache incarcat";
                StatusText.Text = "Gata";
                OutputText.Text = "Informatia este incarcata.\n\nRaport creat automat:\n" + currentReportPath;
            }
            catch (Exception ex) { OutputText.Text = "Eroare: " + ex.Message; }
            finally { cacheLoading = false; LoadingBar.Visibility = Visibility.Collapsed; }
        }

        private async void Refresh_Click(object sender, RoutedEventArgs e) { await StartLoadAsync(true); }
        private async void Login_Click(object sender, RoutedEventArgs e)
        {
            if (SecurityManager.LoginNow(this))
            {
                LoginButton.Content = SecurityManager.CurrentModeLabel();
                StatusText.Text = "Logare activată";
                OutputText.Text = "Logare reușită: " + SecurityManager.CurrentModeLabel() + ". Reîncarc informația...";
                await StartLoadAsync(true);
            }
        }
        private void Update_Click(object sender, RoutedEventArgs e) { UpdateManager.ShowUpdateWindow(this); }
        private void Exit_Click(object sender, RoutedEventArgs e) { Close(); }
        private void Quick_Click(object sender, RoutedEventArgs e) { ShowSection("Informatii rapide", cache.Quick, false); }
        private void Info1C_Click(object sender, RoutedEventArgs e) { ShowSection("Info 1C", cache.Info1C, false); }
        private void Preturi_Click(object sender, RoutedEventArgs e) { ShowSection("Preturi", cache.Preturi, false); }
        private void Bios_Click(object sender, RoutedEventArgs e) { ShowSection("BIOS Password", cache.Bios + "\n\nPentru repornire directa in BIOS/UEFI apasa butonul de mai jos.", true); }

        private void ShowSection(string title, string text, bool biosButton)
        {
            if (!cacheReady) { OutputText.Text = "Informatia inca se incarca."; return; }
            TestPanel.Visibility = Visibility.Collapsed;
            SectionTitle.Text = title;
            StatusText.Text = "Afisat";
            OutputText.Text = string.IsNullOrWhiteSpace(text) ? "Nu exista date." : text;
            BiosRebootButton.Visibility = biosButton ? Visibility.Visible : Visibility.Collapsed;
        }

        private void BiosReboot_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Repornesti direct in BIOS/UEFI?", "BIOS", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                PcInfo.RebootToBios();
        }

        private void DetectCapabilities()
        {
            hasBattery = ExistsWmi("root\\cimv2", "Win32_Battery");
            hasCamera = ExistsPnP("camera|webcam|integrated camera|usb video|imaging");
            hasMicrophone = ExistsPnP("microphone|mic|audio input|realtek.*audio|intel.*audio");
            BatteryTestButton.IsEnabled = hasBattery; BatteryTestButton.Opacity = hasBattery ? 1 : .35;
            CameraTestButton.IsEnabled = hasCamera; CameraTestButton.Opacity = hasCamera ? 1 : .35;
            MicTestButton.IsEnabled = hasMicrophone; MicTestButton.Opacity = hasMicrophone ? 1 : .35;
        }

        private void Tests_Click(object sender, RoutedEventArgs e)
        {
            BiosRebootButton.Visibility = Visibility.Collapsed;
            TestPanel.Visibility = Visibility.Visible;
            SectionTitle.Text = "Teste hardware";
            StatusText.Text = "Teste";
            OutputText.Text = "Alege un test. Butoanele gri sunt indisponibile.\n\nToate rezultatele se salveaza langa program in folderul: Teste.";
        }

        private void ScreenTest_Click(object sender, RoutedEventArgs e)
        {
            MarkTest("Ecran", "Test ecran pornit");
            Brush[] colors = { Brushes.White, Brushes.Black, Brushes.Red, Brushes.Lime, Brushes.Blue, Brushes.Gray, Brushes.Yellow, Brushes.Cyan, Brushes.Magenta };
            int i = 0;
            Window w = new Window { Title = "Test ecran", WindowStyle = WindowStyle.None, WindowState = WindowState.Maximized, Topmost = true, Background = colors[0] };
            TextBlock info = new TextBlock { Text = "SPACE/Click = culoarea urmatoare, ESC = iesire", Foreground = Brushes.White, Background = new SolidColorBrush(Color.FromArgb(150, 0, 0, 0)), FontSize = 28, Padding = new Thickness(18), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 24, 0, 0) };
            Grid g = new Grid(); g.Children.Add(info); w.Content = g;
            Action next = delegate { i = (i + 1) % colors.Length; w.Background = colors[i]; };
            w.KeyDown += delegate(object s, KeyEventArgs k) { if (k.Key == Key.Escape) w.Close(); else if (k.Key == Key.Space || k.Key == Key.Right || k.Key == Key.Enter) next(); };
            w.MouseDown += delegate { next(); };
            w.ShowDialog(); SaveReportFile();
        }

        private void KeyboardTest_Click(object sender, RoutedEventArgs e)
        {
            MarkTest("Tastatura", "Test tastatura pornit");
            Window w = new Window { Title = "Test tastatura", Width = 1320, Height = 740, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner, Background = new SolidColorBrush(Color.FromRgb(8, 12, 26)) };
            keyboardTestWindow = w; keyboardEscCount = 0;
            Grid root = new Grid { Margin = new Thickness(16) };
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            TextBlock title = new TextBlock { Text = "ESC de 2 ori = ieșire", Foreground = Brushes.White, FontSize = 16, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 16) };
            root.Children.Add(title);
            Viewbox view = new Viewbox { Stretch = Stretch.Uniform, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            StackPanel all = new StackPanel { Orientation = Orientation.Horizontal };
            StackPanel main = new StackPanel { Orientation = Orientation.Vertical };
            StackPanel nav = new StackPanel { Orientation = Orientation.Vertical, Margin = new Thickness(16, 0, 0, 0) };
            StackPanel num = new StackPanel { Orientation = Orientation.Vertical, Margin = new Thickness(16, 0, 0, 0) };
            Dictionary<string, List<Border>> boxes = new Dictionary<string, List<Border>>(StringComparer.OrdinalIgnoreCase);
            Dictionary<string, int> presses = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            SortedSet<string> checkedKeys = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            AddRow(main, boxes, new[] { "Esc", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "PrtSc" });
            AddRow(main, boxes, new[] { "`", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=", "Backspace" });
            AddRow(main, boxes, new[] { "Tab", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "[", "]", "\\" });
            AddRow(main, boxes, new[] { "Caps", "A", "S", "D", "F", "G", "H", "J", "K", "L", ";", "'", "Enter" });
            AddRow(main, boxes, new[] { "LShift", "Z", "X", "C", "V", "B", "N", "M", ",", ".", "/", "RShift" });
            AddRow(main, boxes, new[] { "LCtrl", "LWin", "LAlt", "Space", "RAlt", "Menu", "RCtrl" });
            AddRow(nav, boxes, new[] { "Ins", "Home", "PgUp" });
            AddRow(nav, boxes, new[] { "Del", "End", "PgDn" });
            AddRow(nav, boxes, new[] { "", "Up", "" });
            AddRow(nav, boxes, new[] { "Left", "Down", "Right" });
            AddRow(num, boxes, new[] { "Num", "N/", "N*", "N-" });
            AddRow(num, boxes, new[] { "N7", "N8", "N9", "N+" });
            AddRow(num, boxes, new[] { "N4", "N5", "N6", "" });
            AddRow(num, boxes, new[] { "N1", "N2", "N3", "NEnter" });
            AddRow(num, boxes, new[] { "N0", "N.", "" });
            all.Children.Add(main); all.Children.Add(nav); all.Children.Add(num); view.Child = all; Grid.SetRow(view, 1); root.Children.Add(view); w.Content = root;
            keyboardBoxes = boxes; keyboardPresses = presses; keyboardCheckedKeys = checkedKeys;
            StartKeyboardHook();
            w.Closed += delegate { StopKeyboardHook(); SaveKeyboardReport(checkedKeys, presses); keyboardTestWindow = null; SaveReportFile(); };
            w.ShowDialog();
        }

        private void StartKeyboardHook()
        {
            StopKeyboardHook();
            keyboardHookProc = KeyboardHookCallback;
            using (Process curProcess = Process.GetCurrentProcess())
            using (ProcessModule curModule = curProcess.MainModule)
                keyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, keyboardHookProc, GetModuleHandle(curModule.ModuleName), 0);
        }
        private void StopKeyboardHook()
        {
            if (keyboardHook != IntPtr.Zero) { UnhookWindowsHookEx(keyboardHook); keyboardHook = IntPtr.Zero; }
        }
        private IntPtr KeyboardHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && keyboardTestWindow != null && (wParam == (IntPtr)WM_KEYDOWN || wParam == (IntPtr)WM_SYSKEYDOWN))
            {
                KBDLLHOOKSTRUCT data = (KBDLLHOOKSTRUCT)System.Runtime.InteropServices.Marshal.PtrToStructure(lParam, typeof(KBDLLHOOKSTRUCT));
                string key = KeyFromVk(data.vkCode, data.flags);
                if (!string.IsNullOrEmpty(key))
                {
                    keyboardTestWindow.Dispatcher.Invoke(delegate
                    {
                        if (key == "Esc") { keyboardEscCount++; PaintKey(keyboardBoxes, keyboardPresses, keyboardCheckedKeys, "Esc"); if (keyboardEscCount >= 2) keyboardTestWindow.Close(); }
                        else PaintKey(keyboardBoxes, keyboardPresses, keyboardCheckedKeys, key);
                    });
                }
                return (IntPtr)1;
            }
            return CallNextHookEx(keyboardHook, nCode, wParam, lParam);
        }
        private static string KeyFromVk(int vk, int flags)
        {
            bool ext = (flags & LLKHF_EXTENDED) != 0;
            if (vk >= 0x41 && vk <= 0x5A) return ((char)vk).ToString();
            if (vk >= 0x30 && vk <= 0x39) return ((char)vk).ToString();
            if (vk >= 0x70 && vk <= 0x7B) return "F" + (vk - 0x6F).ToString();
            if (vk >= 0x60 && vk <= 0x69) return "N" + (vk - 0x60).ToString();
            switch (vk)
            {
                case 0x1B: return "Esc"; case 0x08: return "Backspace"; case 0x09: return "Tab"; case 0x0D: return ext ? "NEnter" : "Enter"; case 0x14: return "Caps"; case 0x10: return "LShift"; case 0xA0: return "LShift"; case 0xA1: return "RShift"; case 0x11: return ext ? "RCtrl" : "LCtrl"; case 0xA2: return "LCtrl"; case 0xA3: return "RCtrl"; case 0x12: return ext ? "RAlt" : "LAlt"; case 0xA4: return "LAlt"; case 0xA5: return "RAlt"; case 0x5B: return "LWin"; case 0x5C: return "LWin"; case 0x5D: return "Menu"; case 0x20: return "Space"; case 0x2D: return "Ins"; case 0x24: return "Home"; case 0x21: return "PgUp"; case 0x2E: return "Del"; case 0x23: return "End"; case 0x22: return "PgDn"; case 0x25: return "Left"; case 0x26: return "Up"; case 0x27: return "Right"; case 0x28: return "Down"; case 0x2C: return "PrtSc"; case 0x6A: return "N*"; case 0x6B: return "N+"; case 0x6D: return "N-"; case 0x6E: return "N."; case 0x6F: return "N/"; case 0x90: return "Num"; case 0xBA: return ";"; case 0xBB: return "="; case 0xBC: return ","; case 0xBD: return "-"; case 0xBE: return "."; case 0xBF: return "/"; case 0xC0: return "`"; case 0xDB: return "["; case 0xDC: return "\\"; case 0xDD: return "]"; case 0xDE: return "'";
            }
            return "";
        }

        private void AddRow(StackPanel kb, Dictionary<string, List<Border>> map, string[] keys)
        {
            StackPanel row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 6) };
            foreach (string k in keys)
            {
                if (k == "") { row.Children.Add(new Border { Width = 58, Height = 42, Margin = new Thickness(3), Opacity = 0 }); continue; }
                int ww = 54;
                if (k == "Backspace" || k == "Enter") ww = 112;
                if (k == "Tab" || k == "Caps") ww = 90;
                if (k == "LShift" || k == "RShift") ww = 128;
                if (k == "Space") ww = 280;
                if (k == "N0") ww = 112;
                if (k == "NEnter" || k == "N+") ww = 58;
                Border b = new Border { Width = ww, Height = 42, CornerRadius = new CornerRadius(8), BorderThickness = new Thickness(1), BorderBrush = new SolidColorBrush(Color.FromRgb(55, 80, 115)), Background = new SolidColorBrush(Color.FromRgb(25, 35, 55)), Margin = new Thickness(3), Child = new TextBlock { Text = DisplayKey(k), Foreground = Brushes.White, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center } };
                if (!map.ContainsKey(k)) map[k] = new List<Border>();
                map[k].Add(b); row.Children.Add(b);
            }
            kb.Children.Add(row);
        }

        private static string DisplayKey(string k)
        {
            if (k == "Up") return "↑"; if (k == "Down") return "↓"; if (k == "Left") return "←"; if (k == "Right") return "→";
            if (k == "NEnter") return "Enter N";
            if (k == "N+") return "+ N";
            if (k.StartsWith("N")) return k == "Num" ? "Num" : k.Substring(1);
            if (k == "LShift") return "Shift L"; if (k == "RShift") return "Shift R";
            if (k == "LCtrl") return "Ctrl L"; if (k == "RCtrl") return "Ctrl R";
            if (k == "LAlt") return "Alt L"; if (k == "RAlt") return "Alt R";
            if (k == "LWin") return "Win L";
            return k;
        }

        private static string Norm(Key key)
        {
            string k = key.ToString();
            if (k == "Escape") return "Esc"; if (k == "Space") return "Space"; if (k == "Back") return "Backspace";
            if (k.StartsWith("D") && k.Length == 2 && char.IsDigit(k[1])) return k.Substring(1);
            if (k.StartsWith("NumPad") && k.Length == 7) return "N" + k.Substring(6);
            if (k == "Divide") return "N/"; if (k == "Multiply") return "N*"; if (k == "Subtract") return "N-"; if (k == "Add") return "N+"; if (k == "Decimal") return "N."; if (k == "NumLock") return "Num";
            if (k == "Return") return "Enter"; if (k == "Enter") return "NEnter"; if (k == "Capital") return "Caps";
            if (k == "Insert") return "Ins"; if (k == "PageUp") return "PgUp"; if (k == "PageDown") return "PgDn";
            if (k == "LeftShift") return "LShift"; if (k == "RightShift") return "RShift"; if (k == "LeftCtrl") return "LCtrl"; if (k == "RightCtrl") return "RCtrl"; if (k == "LWin") return "LWin"; if (k == "RWin") return "RWin"; if (k == "LeftAlt") return "LAlt"; if (k == "RightAlt") return "RAlt"; if (k == "Apps") return "Menu"; if (k == "Delete") return "Del"; if (k == "Snapshot" || k == "PrintScreen" || k == "SysRq") return "PrtSc";
            if (k == "Oem3") return "`"; if (k == "OemMinus") return "-"; if (k == "OemPlus") return "="; if (k == "OemOpenBrackets" || k == "Oem4") return "["; if (k == "OemCloseBrackets" || k == "Oem6") return "]"; if (k == "Oem5") return "\\"; if (k == "OemSemicolon" || k == "Oem1") return ";"; if (k == "OemQuotes" || k == "Oem7") return "'"; if (k == "OemComma") return ","; if (k == "OemPeriod") return "."; if (k == "OemQuestion" || k == "Oem2") return "/";
            return k;
        }
        private void PaintKey(Dictionary<string, List<Border>> b, Dictionary<string, int> presses, SortedSet<string> checkedKeys, string k)
        {
            if (!b.ContainsKey(k)) return;
            int c = presses.ContainsKey(k) ? presses[k] + 1 : 1;
            presses[k] = c;
            checkedKeys.Add(k);
            if (c <= 1)
            {
                SetGreenOnly(b, k);
            }
            else
            {
                FlashRedThenGreen(b, k);
            }
        }
        private void SetGreenOnly(Dictionary<string, List<Border>> b, string k)
        {
            if (!b.ContainsKey(k)) return;
            foreach (Border br in b[k]) { br.Background = new SolidColorBrush(Color.FromRgb(18, 180, 95)); br.BorderBrush = new SolidColorBrush(Color.FromRgb(120, 255, 200)); }
        }
        private void FlashRedThenGreen(Dictionary<string, List<Border>> b, string k)
        {
            if (!b.ContainsKey(k)) return;
            foreach (Border br in b[k]) { br.Background = new SolidColorBrush(Color.FromRgb(210, 45, 65)); br.BorderBrush = new SolidColorBrush(Color.FromRgb(255, 160, 160)); }
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(180);
            timer.Tick += delegate { timer.Stop(); SetGreenOnly(b, k); };
            timer.Start();
        }

        private void SaveKeyboardReport(SortedSet<string> checkedKeys, Dictionary<string, int> presses)
        {
            try
            {
                EnsureReportFolder(); string dir = Path.Combine(currentReportDir, "Tastatura"); Directory.CreateDirectory(dir);
                StringBuilder sb = new StringBuilder(); sb.AppendLine("Taste verificate: " + checkedKeys.Count); sb.AppendLine(new string('-', 40));
                foreach (string k in checkedKeys) sb.AppendLine(k + " - apasari: " + (presses.ContainsKey(k) ? presses[k] : 1));
                File.WriteAllText(Path.Combine(dir, "Tastatura_Test.txt"), sb.ToString(), Encoding.UTF8);
            }
            catch { }
        }

        private void SoundTest_Click(object s, RoutedEventArgs e) { MarkTest("Sunet", "Test sunet rulat"); try { SystemSounds.Asterisk.Play(); Console.Beep(440, 250); Console.Beep(660, 250); Console.Beep(880, 250); OutputText.Text = "Daca ai auzit 3 tonuri, sunetul functioneaza."; } catch (Exception ex) { OutputText.Text = "Eroare sunet: " + ex.Message; } SaveReportFile(); }
        private void BatteryTest_Click(object s, RoutedEventArgs e) { MarkTest("Baterie", "Baterie verificata"); OutputText.Text = ExtractBatteryLines(PcInfo.GetQuickInfo()); SaveReportFile(); }
        private async void DiskTest_Click(object s, RoutedEventArgs e) { OutputText.Text = "Rulez test disc..."; string r = await Task.Run(() => DiskQuickTest()); MarkTest("Disc", "Test disc efectuat"); OutputText.Text = r; SaveReportFile(); }
        private void RamTest_Click(object s, RoutedEventArgs e) { MarkTest("RAM", "RAM verificat"); OutputText.Text = GetRamInfo(); SaveReportFile(); }
        private void NetworkTest_Click(object s, RoutedEventArgs e) { MarkTest("Retea", "Retea verificata"); OutputText.Text = GetNetworkInfo(); if (MessageBox.Show("Vrei sa deschizi setarile de retea?", "Test retea", MessageBoxButton.YesNo) == MessageBoxResult.Yes) { try { Process.Start(new ProcessStartInfo("ms-settings:network") { UseShellExecute = true }); } catch { try { Process.Start("control.exe", "ncpa.cpl"); } catch { } } } SaveReportFile(); }
        private void UsbTest_Click(object s, RoutedEventArgs e) { StartUsbLiveTest(); }
        private void CameraTest_Click(object s, RoutedEventArgs e) { StartCameraTestWindow(); }
        private void MicTest_Click(object s, RoutedEventArgs e) { StartMicrophoneRecordWindow(); }
        private void Checklist_Click(object s, RoutedEventArgs e) { OutputText.Text = BuildChecklist(); }
        private void Report_Click(object s, RoutedEventArgs e) { EnsureReportFolder(); string rep = BuildReport(); File.WriteAllText(currentReportPath, rep, Encoding.UTF8); OutputText.Text = rep + "\n\nRaport salvat:\n" + currentReportPath; }

        private void EnsureReportFolder()
        {
            if (!string.IsNullOrEmpty(currentReportDir) && Directory.Exists(currentReportDir)) return;
            currentComputerNameSafe = SafeName();
            string root = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Teste");
            currentReportDir = Path.Combine(root, currentComputerNameSafe + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            Directory.CreateDirectory(currentReportDir);
            foreach (string sub in new[] { "Camera", "Audio", "USB", "Retea", "Tastatura", "Ecran", "Disc", "RAM", "Baterie" }) Directory.CreateDirectory(Path.Combine(currentReportDir, sub));
            currentReportPath = Path.Combine(currentReportDir, currentComputerNameSafe + "_Raport.txt");
        }
        private void SaveReportFile() { try { EnsureReportFolder(); File.WriteAllText(currentReportPath, BuildReport(), Encoding.UTF8); } catch { } }
        private string SafeName() { string n = "PCInfoPro"; try { n = (cache.Quick ?? PcInfo.GetQuickInfo()).Split(new[] { "\r\n", "\n" }, StringSplitOptions.None)[0]; } catch { } foreach (char c in Path.GetInvalidFileNameChars()) n = n.Replace(c, '_'); n = Regex.Replace(n, "[^a-zA-Z0-9А-Яа-я _.-]", "_"); return n.Length > 70 ? n.Substring(0, 70) : n; }

        private void StartUsbLiveTest()
        {
            EnsureReportFolder(); string usbFile = Path.Combine(currentReportDir, "USB", "USB_Test.txt");
            Window w = new Window { Title = "Test USB", Width = 780, Height = 500, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner, Background = new SolidColorBrush(Color.FromRgb(8, 12, 26)) };
            DockPanel root = new DockPanel { Margin = new Thickness(16) };
            TextBlock info = new TextBlock { Text = "Conecteaza un stick/mouse/dispozitiv USB. Daca exista deja un dispozitiv USB, este indicat mai jos.", Foreground = Brushes.White, FontSize = 16, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 12) };
            DockPanel.SetDock(info, Dock.Top); root.Children.Add(info);
            TextBox log = new TextBox { Text = GetUsbInfo(), FontFamily = new FontFamily("Consolas"), Foreground = Brushes.White, Background = new SolidColorBrush(Color.FromRgb(3, 10, 20)), IsReadOnly = true, TextWrapping = TextWrapping.Wrap, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            root.Children.Add(log); w.Content = root;
            File.WriteAllText(usbFile, log.Text, Encoding.UTF8);
            if (!log.Text.Contains("Conectati")) { MarkTest("USB", "USB deja conectat / detectat"); SaveReportFile(); }
            ManagementEventWatcher watcher = null;
            try
            {
                watcher = new ManagementEventWatcher(new WqlEventQuery("SELECT * FROM __InstanceCreationEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_PnPEntity'"));
                watcher.EventArrived += delegate(object a, EventArrivedEventArgs b)
                {
                    try
                    {
                        ManagementBaseObject t = (ManagementBaseObject)b.NewEvent["TargetInstance"]; string id = Convert.ToString(t["PNPDeviceID"]); string name = Convert.ToString(t["Name"]);
                        if (id != null && id.StartsWith("USB", StringComparison.OrdinalIgnoreCase)) w.Dispatcher.Invoke(delegate { log.Text += "\n\n[OK] USB conectat acum: " + name; File.WriteAllText(usbFile, log.Text, Encoding.UTF8); MarkTest("USB", "Dispozitiv USB conectat: " + name); SaveReportFile(); });
                    }
                    catch { }
                }; watcher.Start();
            }
            catch (Exception ex) { log.Text += "\n\nMonitorizare USB indisponibila: " + ex.Message; }
            w.Closed += delegate { try { if (watcher != null) { watcher.Stop(); watcher.Dispose(); } } catch { } };
            w.ShowDialog();
        }

        private void StartCameraTestWindow()
        {
            EnsureReportFolder(); string dir = Path.Combine(currentReportDir, "Camera"); Directory.CreateDirectory(dir); MarkTest("Camera", hasCamera ? "Camera test pornit" : "Camera nu a fost detectata automat");
            Window w = new Window { Title = "Test camera", Width = 720, Height = 330, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner, Background = new SolidColorBrush(Color.FromRgb(8, 12, 26)) };
            StackPanel root = new StackPanel { Margin = new Thickness(18) };
            root.Children.Add(new TextBlock { Text = "Pentru poze/video se foloseste aplicatia Microsoft Camera. Windows salveaza pozele in Pictures\\Camera Roll, de aceea am adaugat butonul 'Importa poze/video' ca sa le copieze in mapa raportului.", Foreground = Brushes.White, FontSize = 15, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 14) });
            StackPanel buttons = new StackPanel { Orientation = Orientation.Horizontal };
            Button openCam = new Button { Content = "Deschide Camera", Width = 140, Height = 38, Margin = new Thickness(0, 0, 10, 0) };
            Button installCam = new Button { Content = "Instaleaza Camera", Width = 150, Height = 38, Margin = new Thickness(0, 0, 10, 0) };
            Button importMedia = new Button { Content = "Importa poze/video", Width = 160, Height = 38, Margin = new Thickness(0, 0, 10, 0) };
            Button openFolder = new Button { Content = "Folder Camera", Width = 130, Height = 38 };
            buttons.Children.Add(openCam); buttons.Children.Add(installCam); buttons.Children.Add(importMedia); buttons.Children.Add(openFolder); root.Children.Add(buttons);
            TextBlock status = new TextBlock { Text = "Folder raport Camera: " + dir, Foreground = Brushes.LightGray, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 16, 0, 0) }; root.Children.Add(status); w.Content = root;
            openCam.Click += delegate { try { Process.Start(new ProcessStartInfo("microsoft.windows.camera:") { UseShellExecute = true }); } catch { try { Process.Start(new ProcessStartInfo("explorer.exe", "shell:AppsFolder\\Microsoft.WindowsCamera_8wekyb3d8bbwe!App") { UseShellExecute = true }); } catch (Exception ex) { status.Text = "Nu s-a putut deschide Camera: " + ex.Message; } } };
            installCam.Click += delegate { try { Process.Start(new ProcessStartInfo("ms-windows-store://pdp/?ProductId=9WZDNCRFJBBG") { UseShellExecute = true }); } catch (Exception ex) { status.Text = "Nu s-a putut deschide Store Camera: " + ex.Message; } };
            importMedia.Click += delegate { status.Text = ImportCameraRollFiles(dir); SaveReportFile(); };
            openFolder.Click += delegate { try { Process.Start(new ProcessStartInfo(dir) { UseShellExecute = true }); } catch { } };
            w.ShowDialog(); SaveReportFile();
        }

        private string ImportCameraRollFiles(string destDir)
        {
            try
            {
                string cameraRoll = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "Camera Roll");
                if (!Directory.Exists(cameraRoll)) return "Folderul Windows Camera Roll nu exista: " + cameraRoll;
                string[] patterns = { "*.jpg", "*.jpeg", "*.png", "*.mp4", "*.mov", "*.avi" };
                List<FileInfo> files = new List<FileInfo>();
                foreach (string p in patterns)
                    foreach (string f in Directory.GetFiles(cameraRoll, p)) files.Add(new FileInfo(f));
                files.Sort(delegate(FileInfo a, FileInfo b) { return b.LastWriteTime.CompareTo(a.LastWriteTime); });
                int copied = 0;
                foreach (FileInfo fi in files)
                {
                    if ((DateTime.Now - fi.LastWriteTime).TotalMinutes > 60 && copied > 0) break;
                    string target = Path.Combine(destDir, fi.Name);
                    File.Copy(fi.FullName, target, true);
                    copied++;
                    if (copied >= 10) break;
                }
                MarkTest("Camera", copied > 0 ? "Importate poze/video din Camera Roll: " + copied : "Camera Roll verificat, fara fisiere noi");
                return copied > 0 ? "Importate in raport: " + copied + " fisiere. Folder: " + destDir : "Nu am gasit poze/video recente in Camera Roll. Fa poza/video, apoi apasa din nou Importa.";
            }
            catch (Exception ex) { return "Eroare import Camera Roll: " + ex.Message; }
        }

        private void StartMicrophoneRecordWindow()
        {
            EnsureReportFolder();
            string dir = Path.Combine(currentReportDir, "Audio");
            Directory.CreateDirectory(dir);
            string wav = Path.Combine(dir, "Microfon_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".wav");
            Window w = new Window { Title = "Test microfon", Width = 720, Height = 330, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner, Background = new SolidColorBrush(Color.FromRgb(8, 12, 26)) };
            StackPanel root = new StackPanel { Margin = new Thickness(18) };
            root.Children.Add(new TextBlock { Text = "Metoda 1: Start record / Stop + save inregistreaza direct prin Windows MCI. Daca nu merge, inseamna ca Windows nu permite accesul sau nu exista microfon default. Metoda 2: Deschide Sound Recorder, inregistreaza acolo, apoi apasa Importa inregistrari.", Foreground = Brushes.White, FontSize = 15, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 16) });
            StackPanel buttons = new StackPanel { Orientation = Orientation.Horizontal };
            Button start = new Button { Content = "Start record", Width = 120, Height = 36, Margin = new Thickness(0, 0, 8, 0) };
            Button stop = new Button { Content = "Stop + save", Width = 120, Height = 36, Margin = new Thickness(0, 0, 8, 0), IsEnabled = false };
            Button play = new Button { Content = "Play", Width = 75, Height = 36, Margin = new Thickness(0, 0, 8, 0), IsEnabled = false };
            Button openRecorder = new Button { Content = "Sound Recorder", Width = 135, Height = 36, Margin = new Thickness(0, 0, 8, 0) };
            Button importSound = new Button { Content = "Importa", Width = 90, Height = 36, Margin = new Thickness(0, 0, 8, 0) };
            Button folder = new Button { Content = "Folder Audio", Width = 110, Height = 36 };
            buttons.Children.Add(start); buttons.Children.Add(stop); buttons.Children.Add(play); buttons.Children.Add(openRecorder); buttons.Children.Add(importSound); buttons.Children.Add(folder);
            root.Children.Add(buttons);
            TextBlock st = new TextBlock { Text = "Fisier: " + wav, Foreground = Brushes.LightGray, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 16, 0, 0) };
            root.Children.Add(st); w.Content = root;
            start.Click += delegate
            {
                int r1 = mciSendString("open new type waveaudio alias pcinfopro_rec", null, 0, IntPtr.Zero);
                if (r1 != 0) { st.Text = "Eroare open: " + MciError(r1) + "\nSeteaza microfon default in Windows si verifica permisiunile."; return; }
                int r2 = mciSendString("record pcinfopro_rec", null, 0, IntPtr.Zero);
                if (r2 != 0) { st.Text = "Eroare record: " + MciError(r2); mciSendString("close pcinfopro_rec", null, 0, IntPtr.Zero); return; }
                st.Text = "Se inregistreaza... vorbeste 5-10 secunde, apoi Stop + save."; start.IsEnabled = false; stop.IsEnabled = true; play.IsEnabled = false;
            };
            stop.Click += delegate
            {
                string tempWav = Path.Combine(Path.GetTempPath(), "pcinfopro_mic_test.wav");
                try { if (File.Exists(tempWav)) File.Delete(tempWav); } catch { }
                int r0 = mciSendString("stop pcinfopro_rec", null, 0, IntPtr.Zero);
                int r1 = mciSendString("save pcinfopro_rec \"" + tempWav + "\"", null, 0, IntPtr.Zero);
                mciSendString("close pcinfopro_rec", null, 0, IntPtr.Zero);
                if (r0 != 0 || r1 != 0) { st.Text = "Eroare salvare: " + MciError(r0 != 0 ? r0 : r1) + "\nIncearca metoda Sound Recorder + Importa."; start.IsEnabled = true; stop.IsEnabled = false; return; }
                try { File.Copy(tempWav, wav, true); } catch (Exception ex) { st.Text = "Fisier temporar creat, dar nu pot copia in raport: " + ex.Message; return; }
                st.Text = "Salvat: " + wav; start.IsEnabled = true; stop.IsEnabled = false; play.IsEnabled = true;
                MarkTest("Microfon", "Inregistrare salvata: " + wav); SaveReportFile();
            };
            play.Click += delegate { try { new SoundPlayer(wav).Play(); } catch (Exception ex) { st.Text = "Eroare redare: " + ex.Message; } };
            openRecorder.Click += delegate { try { Process.Start(new ProcessStartInfo("ms-soundrecorder:") { UseShellExecute = true }); } catch { try { Process.Start("soundrecorder.exe"); } catch (Exception ex) { st.Text = "Nu pot deschide Sound Recorder: " + ex.Message; } } };
            importSound.Click += delegate { st.Text = ImportSoundRecordings(dir); SaveReportFile(); };
            folder.Click += delegate { try { Process.Start(new ProcessStartInfo(dir) { UseShellExecute = true }); } catch { } };
            w.Closed += delegate { try { mciSendString("close pcinfopro_rec", null, 0, IntPtr.Zero); } catch { } };
            w.ShowDialog();
        }

        private string MciError(int code)
        {
            if (code == 0) return "OK";
            StringBuilder sb = new StringBuilder(512);
            if (mciGetErrorString(code, sb, sb.Capacity)) return sb.ToString();
            return "cod " + code;
        }

        private string ImportSoundRecordings(string destDir)
        {
            try
            {
                List<string> roots = new List<string>();
                roots.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Sound recordings"));
                roots.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyMusic), "Sound recordings"));
                string user = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
                roots.Add(Path.Combine(user, "OneDrive", "Documents", "Sound recordings"));
                roots.Add(Path.Combine(user, "OneDrive", "Документы", "Звукозаписи"));
                List<FileInfo> files = new List<FileInfo>();
                foreach (string r in roots)
                    if (Directory.Exists(r))
                        foreach (string f in Directory.GetFiles(r, "*.*"))
                            if (Regex.IsMatch(f, "\\.(m4a|wav|mp3|wma)$", RegexOptions.IgnoreCase)) files.Add(new FileInfo(f));
                files.Sort(delegate(FileInfo a, FileInfo b) { return b.LastWriteTime.CompareTo(a.LastWriteTime); });
                int copied = 0;
                foreach (FileInfo fi in files)
                {
                    string target = Path.Combine(destDir, fi.Name);
                    File.Copy(fi.FullName, target, true);
                    copied++; if (copied >= 10) break;
                }
                MarkTest("Microfon", copied > 0 ? "Importate inregistrari audio: " + copied : "Nu s-au gasit inregistrari audio");
                return copied > 0 ? "Importate in folder Audio: " + copied + " fisiere." : "Nu am gasit inregistrari. Inregistreaza in Sound Recorder si apasa din nou Importa.";
            }
            catch (Exception ex) { return "Eroare import audio: " + ex.Message; }
        }

        private void MarkTest(string n, string r) { testResults[n] = DateTime.Now.ToString("HH:mm") + " - " + r; }
        private string BuildChecklist() { string[] names = { "Ecran", "Tastatura", "Sunet", "Baterie", "Disc", "RAM", "Retea", "USB", "Camera", "Microfon" }; StringBuilder sb = new StringBuilder(); sb.AppendLine("Checklist verificare calculator"); sb.AppendLine(new string('-', 45)); foreach (string n in names) sb.AppendLine((testResults.ContainsKey(n) ? "[OK] " : "[  ] ") + n + (testResults.ContainsKey(n) ? " - " + testResults[n] : "")); return sb.ToString(); }
        private string BuildReport() { StringBuilder sb = new StringBuilder(); sb.AppendLine("PCInfoPro - Raport verificare service"); sb.AppendLine("Data: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); if (!string.IsNullOrEmpty(currentReportDir)) sb.AppendLine("Mapa raport: " + currentReportDir); sb.AppendLine(new string('=', 55)); sb.AppendLine("\nINFORMATII RAPIDE"); sb.AppendLine(cacheReady ? cache.Quick : PcInfo.GetQuickInfo()); sb.AppendLine("\nTESTE EFECTUATE"); sb.AppendLine(BuildChecklist()); return sb.ToString(); }
        private static bool ExistsWmi(string ns, string cls) { try { using (var s = new ManagementObjectSearcher(ns, "SELECT * FROM " + cls)) foreach (ManagementObject o in s.Get()) return true; } catch { } return false; }
        private static bool ExistsPnP(string regex) { try { Regex r = new Regex(regex, RegexOptions.IgnoreCase); using (var s = new ManagementObjectSearcher("root\\cimv2", "SELECT Name, Description FROM Win32_PnPEntity")) foreach (ManagementObject o in s.Get()) { string n = Convert.ToString(o["Name"]) + " " + Convert.ToString(o["Description"]); if (r.IsMatch(n)) return true; } } catch { } return false; }
        private static string ExtractBatteryLines(string q) { StringBuilder sb = new StringBuilder(); foreach (string l in q.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None)) if (l.ToLower().Contains("bater") || l.ToLower().Contains("cicluri")) sb.AppendLine(l); return sb.Length == 0 ? "Nu exista baterie detectata." : sb.ToString(); }
        private static string DiskQuickTest() { StringBuilder sb = new StringBuilder(); try { string tmp = Path.Combine(Path.GetTempPath(), "pcinfopro_disk_test.bin"); byte[] data = new byte[8 * 1024 * 1024]; new Random(7).NextBytes(data); Stopwatch sw = Stopwatch.StartNew(); File.WriteAllBytes(tmp, data); sw.Stop(); double w = data.Length / 1024.0 / 1024.0 / Math.Max(.001, sw.Elapsed.TotalSeconds); sw.Restart(); byte[] rd = File.ReadAllBytes(tmp); sw.Stop(); double r = rd.Length / 1024.0 / 1024.0 / Math.Max(.001, sw.Elapsed.TotalSeconds); File.Delete(tmp); sb.AppendLine("Test disc rapid"); sb.AppendLine("Scriere: " + w.ToString("0.0") + " MB/s"); sb.AppendLine("Citire:  " + r.ToString("0.0") + " MB/s"); using (var s = new ManagementObjectSearcher("SELECT Model, InterfaceType, Status FROM Win32_DiskDrive")) foreach (ManagementObject d in s.Get()) sb.AppendLine("- " + d["Model"] + " | " + d["InterfaceType"] + " | " + d["Status"]); } catch (Exception ex) { sb.AppendLine("Eroare: " + ex.Message); } return sb.ToString(); }
        private static string GetRamInfo() { StringBuilder sb = new StringBuilder(); long total = 0; int i = 1; try { using (var s = new ManagementObjectSearcher("SELECT Capacity, Speed, Manufacturer, PartNumber FROM Win32_PhysicalMemory")) foreach (ManagementObject m in s.Get()) { long c = Convert.ToInt64(m["Capacity"]); total += c; sb.AppendLine("Slot " + (i++) + ": " + Math.Round(c / 1024.0 / 1024 / 1024, 0) + " GB, " + m["Speed"] + " MHz, " + m["Manufacturer"] + " " + m["PartNumber"]); } sb.AppendLine("Total: " + Math.Round(total / 1024.0 / 1024 / 1024, 0) + " GB"); } catch (Exception ex) { sb.AppendLine("Eroare: " + ex.Message); } return sb.ToString(); }
        private static string GetNetworkInfo() { StringBuilder sb = new StringBuilder(); bool connected = false; try { foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces()) { if (ni.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue; if (ni.OperationalStatus == OperationalStatus.Up) connected = true; sb.AppendLine("- " + ni.Name + " | " + ni.NetworkInterfaceType + " | " + ni.OperationalStatus); foreach (UnicastIPAddressInformation addr in ni.GetIPProperties().UnicastAddresses) if (addr.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork) sb.AppendLine("  IP: " + addr.Address); foreach (GatewayIPAddressInformation gw in ni.GetIPProperties().GatewayAddresses) sb.AppendLine("  Gateway: " + gw.Address); } sb.AppendLine("\nConectat la retea: " + (connected ? "DA" : "NU")); PingReply pr = new Ping().Send("8.8.8.8", 1500); sb.AppendLine("Ping 8.8.8.8: " + pr.Status + (pr.Status == IPStatus.Success ? " " + pr.RoundtripTime + " ms" : "")); } catch (Exception ex) { sb.AppendLine("Eroare: " + ex.Message); } return sb.ToString(); }
        private static string GetUsbInfo()
        {
            StringBuilder sb = new StringBuilder();
            bool any = false;
            sb.AppendLine("USB detectat acum:");
            try
            {
                using (var searcher = new ManagementObjectSearcher("SELECT Name, Status, PNPDeviceID FROM Win32_PnPEntity WHERE PNPDeviceID LIKE 'USB%'") )
                foreach (ManagementObject o in searcher.Get())
                {
                    string name = Convert.ToString(o["Name"]);
                    string id = Convert.ToString(o["PNPDeviceID"]);
                    if (string.IsNullOrWhiteSpace(name)) continue;
                    if (Regex.IsMatch(name, "root hub|host controller|composite parent", RegexOptions.IgnoreCase)) continue;
                    any = true;
                    string hint = "";
                    if (!string.IsNullOrEmpty(id) && id.IndexOf("VID_", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        int p = id.IndexOf("VID_", StringComparison.OrdinalIgnoreCase);
                        hint = " (" + id.Substring(p, Math.Min(17, id.Length - p)) + ")";
                    }
                    sb.AppendLine("- " + name + hint);
                }
            }
            catch (Exception ex) { sb.AppendLine("Eroare: " + ex.Message); }
            if (!any) sb.AppendLine("- nimic extern clar detectat. Conecteaza un dispozitiv in portul liber.");
            sb.AppendLine();
            sb.AppendLine("Clarificare: programul nu poate sti cate porturi fizice sunt libere; verifica porturile conectand un dispozitiv pe rand.");
            return sb.ToString();
        }
    }

    public class CacheData
    {
        public string Quick { get; set; }
        public string Info1C { get; set; }
        public string Preturi { get; set; }
        public string Bios { get; set; }
    }

}
