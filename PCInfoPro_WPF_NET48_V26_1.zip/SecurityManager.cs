using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Management;
using System.Security.Cryptography;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;

namespace PCInfoPro
{
    public static class SecurityManager
    {
        private const string Salt = "PCInfoProSecure|";
        private const string AdminHash = "531DA878C99F824E17442EB5EBB6F0547052AF4B367E3871F5424D8680B2F971";
        private const string UserHash = "94B1FC9994EA6B5E6A0DC5C0DF4474B8ED67D55ED776CDCFF46988DB4B1F8757";
        private const int TrialDays = 30;
        private const int UserDays = 180;
        private const int MaxUserActivations = 2;
        private const string RegistryPath = @"Software\InformatieCalculator";
        private const string RegistryValue = "License";
        private const string LicenseFile = "license.dat";

        private class LicenseData
        {
            public string Mode;
            public string FirstPC;
            public long StartTicks;
            public long ExpireTicks;
            public int UserActivations;
            public string Stamp;
        }

        public static bool EnsureAccess(Window owner)
        {
            string pc = CurrentPcHash();
            LicenseData lic = LoadLicense();

            if (lic != null && IsLicenseUsable(lic, pc))
            {
                RepairCopies(lic);
                return true;
            }

            if (lic != null && lic.Mode != "Admin" && lic.ExpireTicks > 0 && DateTime.UtcNow.Ticks > lic.ExpireTicks)
            {
                CleanupProgramData();
            }

            while (true)
            {
                string code = null;
                bool trial = false;
                bool cancel = false;
                ShowCodeDialog(owner, out code, out trial, out cancel, lic, pc);
                if (cancel) return false;
                if (trial)
                {
                    LicenseData trialLic = lic;
                    if (trialLic != null && trialLic.Mode == "Trial" && trialLic.FirstPC == pc && DateTime.UtcNow.Ticks <= trialLic.ExpireTicks)
                    {
                        SaveAll(trialLic);
                        return true;
                    }
                    if (trialLic != null && trialLic.Mode == "Trial" && DateTime.UtcNow.Ticks > trialLic.ExpireTicks)
                    {
                        MessageBox.Show("Perioada gratuită de 30 zile a expirat. Introduceți codul de activare.", "Activare", MessageBoxButton.OK, MessageBoxImage.Warning);
                        continue;
                    }
                    LicenseData newTrial = NewLicense("Trial", pc, TrialDays, lic == null ? 0 : lic.UserActivations);
                    SaveAll(newTrial);
                    return true;
                }

                if (string.IsNullOrWhiteSpace(code)) continue;
                string h = HashCode(code.Trim());
                if (h == AdminHash)
                {
                    LicenseData admin = NewLicense("Admin", pc, 0, lic == null ? 0 : lic.UserActivations);
                    SaveAll(admin);
                    return true;
                }
                if (h == UserHash)
                {
                    int used = lic == null ? 0 : lic.UserActivations;
                    if (lic != null && lic.Mode == "User" && lic.FirstPC != pc)
                    {
                        MessageBox.Show("Acest program este activat pe alt calculator. Introduceți codul Admin pentru reactivare.", "Activare", MessageBoxButton.OK, MessageBoxImage.Stop);
                        continue;
                    }
                    if (used >= MaxUserActivations && (lic == null || lic.Mode != "Admin"))
                    {
                        MessageBox.Show("Limita de 2 activări Utilizator a fost atinsă. Introduceți codul Admin.", "Activare", MessageBoxButton.OK, MessageBoxImage.Stop);
                        continue;
                    }
                    LicenseData user = NewLicense("User", pc, UserDays, used + 1);
                    SaveAll(user);
                    return true;
                }
                MessageBox.Show("Cod incorect.", "Activare", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public static string CurrentModeLabel()
        {
            try
            {
                string pc = CurrentPcHash();
                LicenseData lic = LoadLicense();
                if (lic != null && IsLicenseUsable(lic, pc))
                {
                    if (lic.Mode == "Admin") return "Administrator";
                    if (lic.Mode == "User") return "Utilizator";
                    if (lic.Mode == "Trial") return "Trial";
                }
            }
            catch { }
            return "Logare";
        }

        public static bool LoginNow(Window owner)
        {
            string pc = CurrentPcHash();
            LicenseData lic = LoadLicense();
            string code = ShowLoginDialog(owner, lic, pc);
            if (string.IsNullOrWhiteSpace(code)) return false;

            string h = HashCode(code.Trim());
            if (h == AdminHash)
            {
                LicenseData admin = NewLicense("Admin", pc, 0, lic == null ? 0 : lic.UserActivations);
                SaveAll(admin);
                MessageBox.Show("Logare Admin reușită. Acces nelimitat activat.", "Logare", MessageBoxButton.OK, MessageBoxImage.Information);
                return true;
            }

            if (h == UserHash)
            {
                int used = lic == null ? 0 : lic.UserActivations;
                if (lic != null && lic.Mode == "User" && lic.FirstPC != pc)
                {
                    MessageBox.Show("Acest program este activat pe alt calculator. Pentru mutare este necesar cod Admin.", "Logare", MessageBoxButton.OK, MessageBoxImage.Stop);
                    return false;
                }
                if (used >= MaxUserActivations && (lic == null || lic.Mode != "Admin"))
                {
                    MessageBox.Show("Limita de 2 activări Utilizator a fost atinsă. Introduceți codul Admin.", "Logare", MessageBoxButton.OK, MessageBoxImage.Stop);
                    return false;
                }
                LicenseData user = NewLicense("User", pc, UserDays, used + 1);
                SaveAll(user);
                MessageBox.Show("Logare Utilizator reușită. Activare valabilă 180 zile.", "Logare", MessageBoxButton.OK, MessageBoxImage.Information);
                return true;
            }

            MessageBox.Show("Cod incorect.", "Logare", MessageBoxButton.OK, MessageBoxImage.Error);
            return false;
        }

        private static LicenseData NewLicense(string mode, string pc, int days, int activations)
        {
            DateTime now = DateTime.UtcNow;
            return new LicenseData
            {
                Mode = mode,
                FirstPC = pc,
                StartTicks = now.Ticks,
                ExpireTicks = mode == "Admin" ? 0 : now.AddDays(days).Ticks,
                UserActivations = activations,
                Stamp = Guid.NewGuid().ToString("N")
            };
        }

        private static bool IsLicenseUsable(LicenseData lic, string pc)
        {
            if (lic == null) return false;
            if (lic.Mode == "Admin") return true;
            if (lic.FirstPC != pc) return false;
            if (lic.ExpireTicks > 0 && DateTime.UtcNow.Ticks > lic.ExpireTicks) return false;
            if (lic.Mode == "User" && lic.UserActivations > MaxUserActivations) return false;
            return true;
        }

        private static void ShowCodeDialog(Window owner, out string code, out bool trial, out bool cancel, LicenseData lic, string pc)
        {
            string localCode = null;
            bool localTrial = false;
            bool localCancel = false;

            Window w = new Window
            {
                Title = "Activare",
                Width = 460,
                Height = 290,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize,
                Background = new SolidColorBrush(Color.FromRgb(8, 12, 26)),
                Topmost = true
            };
            StackPanel root = new StackPanel { Margin = new Thickness(26) };
            root.Children.Add(new TextBlock { Text = "Informație despre Calculator", Foreground = Brushes.White, FontSize = 24, FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center });
            root.Children.Add(new TextBlock { Text = "Introduce codul", Foreground = new SolidColorBrush(Color.FromRgb(126, 234, 218)), FontSize = 15, Margin = new Thickness(0, 14, 0, 8), HorizontalAlignment = HorizontalAlignment.Center });
            PasswordBox box = new PasswordBox { Height = 38, FontSize = 18, Margin = new Thickness(0, 0, 0, 14) };
            root.Children.Add(box);
            TextBlock info = new TextBlock { Foreground = new SolidColorBrush(Color.FromRgb(160, 175, 200)), FontSize = 12, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 16) };
            info.Text = BuildInfoText(lic, pc);
            root.Children.Add(info);
            StackPanel buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center };
            Button ok = new Button { Content = "Intră", Width = 110, Height = 34, Margin = new Thickness(5) };
            Button trialBtn = new Button { Content = "Continuă fără cod", Width = 150, Height = 34, Margin = new Thickness(5) };
            Button exit = new Button { Content = "Ieșire", Width = 90, Height = 34, Margin = new Thickness(5) };
            buttons.Children.Add(ok); buttons.Children.Add(trialBtn); buttons.Children.Add(exit);
            root.Children.Add(buttons);
            w.Content = root;

            ok.Click += delegate { localCode = box.Password; w.DialogResult = true; w.Close(); };
            trialBtn.Click += delegate { localTrial = true; w.DialogResult = true; w.Close(); };
            exit.Click += delegate { localCancel = true; w.DialogResult = false; w.Close(); };
            box.KeyDown += delegate(object sender, System.Windows.Input.KeyEventArgs e)
            {
                if (e.Key == System.Windows.Input.Key.Enter)
                {
                    localCode = box.Password;
                    w.DialogResult = true;
                    w.Close();
                }
            };

            bool? res = w.ShowDialog();
            if (res != true && !localTrial && localCode == null) localCancel = true;

            code = localCode;
            trial = localTrial;
            cancel = localCancel;
        }

        private static string ShowLoginDialog(Window owner, LicenseData lic, string pc)
        {
            string localCode = null;
            Window w = new Window
            {
                Title = "Logare",
                Width = 430,
                Height = 235,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize,
                Background = new SolidColorBrush(Color.FromRgb(8, 12, 26)),
                Topmost = true,
                Owner = owner
            };
            StackPanel root = new StackPanel { Margin = new Thickness(26) };
            root.Children.Add(new TextBlock { Text = "Logare", Foreground = Brushes.White, FontSize = 24, FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center });
            root.Children.Add(new TextBlock { Text = "Introduce codul", Foreground = new SolidColorBrush(Color.FromRgb(126, 234, 218)), FontSize = 15, Margin = new Thickness(0, 14, 0, 8), HorizontalAlignment = HorizontalAlignment.Center });
            PasswordBox box = new PasswordBox { Height = 38, FontSize = 18, Margin = new Thickness(0, 0, 0, 14) };
            root.Children.Add(box);
            TextBlock info = new TextBlock { Foreground = new SolidColorBrush(Color.FromRgb(160, 175, 200)), FontSize = 12, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 14) };
            info.Text = BuildInfoText(lic, pc);
            root.Children.Add(info);
            StackPanel buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center };
            Button ok = new Button { Content = "Intră", Width = 110, Height = 34, Margin = new Thickness(5) };
            Button exit = new Button { Content = "Anulează", Width = 100, Height = 34, Margin = new Thickness(5) };
            buttons.Children.Add(ok); buttons.Children.Add(exit);
            root.Children.Add(buttons);
            w.Content = root;
            ok.Click += delegate { localCode = box.Password; w.DialogResult = true; w.Close(); };
            exit.Click += delegate { localCode = null; w.DialogResult = false; w.Close(); };
            box.KeyDown += delegate(object sender, System.Windows.Input.KeyEventArgs e)
            {
                if (e.Key == System.Windows.Input.Key.Enter)
                {
                    localCode = box.Password;
                    w.DialogResult = true;
                    w.Close();
                }
            };
            w.ShowDialog();
            return localCode;
        }

        private static string BuildInfoText(LicenseData lic, string pc)
        {
            if (lic == null) return "Admin: nelimitat. Utilizator: 180 zile. Fără cod: 30 zile.";
            if (lic.Mode == "Admin") return "Mod Admin detectat.";
            if (lic.FirstPC != pc) return "Licența aparține altui calculator. Este necesar cod Admin.";
            if (lic.ExpireTicks > 0)
            {
                int days = (int)Math.Ceiling((new DateTime(lic.ExpireTicks) - DateTime.UtcNow).TotalDays);
                if (days < 0) days = 0;
                return "Licență: " + lic.Mode + ". Zile rămase: " + days + ". Activări utilizator: " + lic.UserActivations + "/" + MaxUserActivations + ".";
            }
            return "Introduce codul.";
        }

        private static string HashCode(string code)
        {
            using (SHA256 sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(Salt + code))).Replace("-", "").ToUpperInvariant();
        }

        private static string CurrentPcHash()
        {
            string raw = ReadMachineGuid() + "|" + WmiFirst("Win32_BIOS", "SerialNumber") + "|" + WmiFirst("Win32_BaseBoard", "SerialNumber") + "|" + WmiFirst("Win32_Processor", "ProcessorId") + "|" + WmiFirst("Win32_DiskDrive", "SerialNumber");
            using (SHA256 sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(raw))).Replace("-", "").ToUpperInvariant();
        }

        private static string ReadMachineGuid()
        {
            try { using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Cryptography")) return Convert.ToString(k.GetValue("MachineGuid")); } catch { return ""; }
        }

        private static string WmiFirst(string cls, string prop)
        {
            try
            {
                using (ManagementObjectSearcher s = new ManagementObjectSearcher("SELECT " + prop + " FROM " + cls))
                    foreach (ManagementObject o in s.Get()) return Convert.ToString(o[prop]);
            } catch { }
            return "";
        }

        private static LicenseData LoadLicense()
        {
            List<LicenseData> found = new List<LicenseData>();
            foreach (string path in LicensePaths())
            {
                try { if (File.Exists(path)) { LicenseData l = Decode(File.ReadAllText(path)); if (l != null) found.Add(l); } } catch { }
            }
            try
            {
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(RegistryPath))
                {
                    if (k != null)
                    {
                        string v = Convert.ToString(k.GetValue(RegistryValue));
                        LicenseData l = Decode(v);
                        if (l != null) found.Add(l);
                    }
                }
            } catch { }
            if (found.Count == 0) return null;
            return found.OrderByDescending(x => x.StartTicks).First();
        }

        private static void RepairCopies(LicenseData lic) { SaveAll(lic); }

        private static void SaveAll(LicenseData lic)
        {
            string encoded = Encode(lic);
            foreach (string path in LicensePaths())
            {
                try { Directory.CreateDirectory(Path.GetDirectoryName(path)); File.WriteAllText(path, encoded); } catch { }
            }
            try
            {
                using (RegistryKey k = Registry.CurrentUser.CreateSubKey(RegistryPath)) k.SetValue(RegistryValue, encoded, RegistryValueKind.String);
            } catch { }
        }

        private static IEnumerable<string> LicensePaths()
        {
            yield return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, LicenseFile);
            yield return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "InformatieCalculator", LicenseFile);
        }

        private static string Encode(LicenseData l)
        {
            string plain = string.Join("|", new string[] { l.Mode, l.FirstPC, l.StartTicks.ToString(), l.ExpireTicks.ToString(), l.UserActivations.ToString(), l.Stamp });
            byte[] data = ProtectedData.Protect(Encoding.UTF8.GetBytes(plain), null, DataProtectionScope.CurrentUser);
            return Convert.ToBase64String(data);
        }

        private static LicenseData Decode(string encoded)
        {
            if (string.IsNullOrWhiteSpace(encoded)) return null;
            try
            {
                byte[] raw = ProtectedData.Unprotect(Convert.FromBase64String(encoded), null, DataProtectionScope.CurrentUser);
                string[] p = Encoding.UTF8.GetString(raw).Split('|');
                if (p.Length < 6) return null;
                return new LicenseData { Mode = p[0], FirstPC = p[1], StartTicks = long.Parse(p[2]), ExpireTicks = long.Parse(p[3]), UserActivations = int.Parse(p[4]), Stamp = p[5] };
            } catch { return null; }
        }

        private static void CleanupProgramData()
        {
            try
            {
                string tests = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Teste");
                if (Directory.Exists(tests)) Directory.Delete(tests, true);
            } catch { }
        }
    }
}
