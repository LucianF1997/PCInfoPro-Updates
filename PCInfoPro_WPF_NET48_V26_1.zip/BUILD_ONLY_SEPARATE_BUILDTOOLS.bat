@echo off
setlocal
cd /d "%~dp0"
set "MSBUILD=C:\VSBuildToolsPCInfo\MSBuild\Current\Bin\MSBuild.exe"
set "ROSLYN=C:\VSBuildToolsPCInfo\MSBuild\Current\Bin\Roslyn\Microsoft.CSharp.Core.targets"
if not exist "%MSBUILD%" (echo Run INSTALL_SEPARATE_BUILDTOOLS_AND_BUILD.bat first.& pause & exit /b 1)
if not exist "%ROSLYN%" (echo Roslyn missing.& pause & exit /b 1)
"%MSBUILD%" PCInfoPro.csproj /p:Configuration=Release /p:Platform="AnyCPU"
if errorlevel 1 (echo Build failed.& pause & exit /b 1)
echo SUCCESS: bin\Release\PCInfoPro.exe
pause
